See doc/users/installing/index.rst
