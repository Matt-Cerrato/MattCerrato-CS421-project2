Fixed errorbars in polar plots
------------------------------
Caps and error lines are now drawn with respect to polar coordinates,
when plotting errorbars on polar plots.

.. figure:: /gallery/pie_and_polar_charts/images/sphx_glr_polar_error_caps_001.png
   :target: ../../gallery/pie_and_polar_charts/polar_error_caps.html
