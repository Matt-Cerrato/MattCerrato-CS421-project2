Reversed order of legend entries
--------------------------------
The order of legend entries can now be reversed by passing ``reverse=True`` to
`~.Axes.legend`.
