New & Improved Narrative Documentation
======================================
* Brand new :doc:`Animations </tutorials/introductory/animation_tutorial>` tutorial.
* New grouped and stacked `bar chart <../../gallery/index.html#lines_bars_and_markers>`_ examples.
* New section for new contributors and reorganized git instructions in the :ref:`contributing guide<contributing>`.
* Restructured :doc:`/tutorials/text/annotations` tutorial.
