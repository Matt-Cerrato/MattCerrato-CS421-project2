*********************
``matplotlib.legend``
*********************

.. automodule:: matplotlib.legend
   :members:
   :undoc-members:
   :show-inheritance:
