Deprecated modules removed
~~~~~~~~~~~~~~~~~~~~~~~~~~

The following deprecated modules are removed:

* ``afm``
* ``docstring``
* ``fontconfig_pattern``
* ``tight_bbox``
* ``tight_layout``
* ``type1font``
