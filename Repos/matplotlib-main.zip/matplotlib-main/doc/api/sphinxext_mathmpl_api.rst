================================
``matplotlib.sphinxext.mathmpl``
================================

.. automodule:: matplotlib.sphinxext.mathmpl
   :exclude-members: latex_math
   :no-undoc-members:
