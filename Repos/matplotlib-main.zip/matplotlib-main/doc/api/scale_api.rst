********************
``matplotlib.scale``
********************

.. automodule:: matplotlib.scale
   :members:
   :undoc-members:
   :show-inheritance:
