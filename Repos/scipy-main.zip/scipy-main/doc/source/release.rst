*************
Release Notes
*************

This is the list of changes to SciPy between each release. For full details,-notes
see the `commit logs <https://github.com/scipy/scipy/commits/>`_.

.. toctree::
   :maxdepth: 1

   release/1.11.0-notes
   release/1.10.1-notes
   release/1.10.0-notes
   release/1.9.3-notes
   release/1.9.2-notes
   release/1.9.1-notes
   release/1.9.0-notes
   release/1.8.1-notes
   release/1.8.0-notes
   release/1.7.3-notes
   release/1.7.2-notes
   release/1.7.1-notes
   release/1.7.0-notes
   release/1.6.3-notes
   release/1.6.2-notes
   release/1.6.1-notes
   release/1.6.0-notes
   release/1.5.4-notes
   release/1.5.3-notes
   release/1.5.2-notes
   release/1.5.1-notes
   release/1.5.0-notes
   release/1.4.1-notes
   release/1.4.0-notes
   release/1.3.3-notes
   release/1.3.2-notes
   release/1.3.1-notes
   release/1.3.0-notes
   release/1.2.3-notes
   release/1.2.2-notes
   release/1.2.1-notes
   release/1.2.0-notes
   release/1.1.0-notes
   release/1.0.1-notes
   release/1.0.0-notes
   release/0.19.1-notes
   release/0.19.0-notes
   release/0.18.1-notes
   release/0.18.0-notes
   release/0.17.1-notes
   release/0.17.0-notes
   release/0.16.1-notes
   release/0.16.0-notes
   release/0.15.1-notes
   release/0.15.0-notes
   release/0.14.1-notes
   release/0.14.0-notes
   release/0.13.2-notes
   release/0.13.1-notes
   release/0.13.0-notes
   release/0.12.1-notes
   release/0.12.0-notes
   release/0.11.0-notes
   release/0.10.1-notes
   release/0.10.0-notes
   release/0.9.0-notes
   release/0.8.0-notes
   release/0.7.2-notes
   release/0.7.1-notes
   release/0.7.0-notes
