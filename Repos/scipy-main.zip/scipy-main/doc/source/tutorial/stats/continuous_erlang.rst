
.. _continuous-erlang:

Erlang Distribution
===================

This is just the Gamma distribution with shape parameter :math:`\alpha=n` an integer.

Implementation: `scipy.stats.erlang`
