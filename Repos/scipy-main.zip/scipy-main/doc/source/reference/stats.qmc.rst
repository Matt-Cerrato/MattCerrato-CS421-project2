.. automodule:: scipy.stats.qmc
   :no-members:
   :no-inherited-members:
   :no-special-members:
