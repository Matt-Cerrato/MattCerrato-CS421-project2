.. _optimize.linprog-highs-ds:

linprog(method='highs-ds')
----------------------------------------

.. scipy-optimize:function:: scipy.optimize.linprog
   :impl: scipy.optimize._linprog._linprog_highs_ds_doc
   :method: highs-ds
