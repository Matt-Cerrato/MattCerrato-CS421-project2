.. _optimize.minimize_scalar-golden:

minimize_scalar(method='golden')
-----------------------------------------------

.. scipy-optimize:function:: scipy.optimize.minimize_scalar
   :impl: scipy.optimize._optimize._minimize_scalar_golden
   :method: golden
