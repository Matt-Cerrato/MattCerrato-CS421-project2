.. automodule:: scipy.fft
   :no-members:
   :no-inherited-members:
   :no-special-members:
