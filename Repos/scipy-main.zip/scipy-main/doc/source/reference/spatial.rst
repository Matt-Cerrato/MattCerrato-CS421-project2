.. automodule:: scipy.spatial
   :no-members:
   :no-inherited-members:
   :no-special-members:
