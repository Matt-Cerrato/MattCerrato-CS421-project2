.. _optimize.root_scalar-newton:

root_scalar(method='newton')
----------------------------

.. scipy-optimize:function:: scipy.optimize.root_scalar
   :impl: scipy.optimize._root_scalar._root_scalar_newton_doc
   :method: newton

